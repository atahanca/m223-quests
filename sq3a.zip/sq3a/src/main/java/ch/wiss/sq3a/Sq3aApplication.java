package ch.wiss.sq3a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sq3aApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sq3aApplication.class, args);
	}

}
