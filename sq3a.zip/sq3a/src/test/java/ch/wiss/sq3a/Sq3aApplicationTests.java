package ch.wiss.sq3a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sq3aApplicationTests {

	@Test
	void contextLoads() {
	}

}
